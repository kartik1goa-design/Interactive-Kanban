const STORAGE_KEYS = {
  tasks: "flowboard.tasks.v1",
  activity: "flowboard.activity.v1",
  theme: "flowboard.theme.v1",
};

// The status IDs are used by task data, filters, and the matching board columns.
const COLUMNS = [
  { id: "todo", title: "To Do", className: "column-todo" },
  { id: "progress", title: "In Progress", className: "column-progress" },
  { id: "done", title: "Done", className: "column-done" },
];

const initialTasks = [
  {
    id: "task-brief",
    title: "Finalize product brief",
    description: "Align the team on scope, goals, and launch milestones.",
    priority: "high",
    dueDate: daysFromToday(1),
    tags: ["Planning", "Feature"],
    status: "todo",
  },
  {
    id: "task-research",
    title: "Review user research",
    description: "Pull out the top usability themes from recent interviews.",
    priority: "medium",
    dueDate: daysFromToday(4),
    tags: ["Research", "Design"],
    status: "todo",
  },
  {
    id: "task-header",
    title: "Fix responsive header",
    description: "Check the navigation spacing on smaller screens.",
    priority: "high",
    dueDate: daysFromToday(-1),
    tags: ["Bug", "Design"],
    status: "progress",
  },
  {
    id: "task-dashboard",
    title: "Build dashboard overview",
    description: "Create the first pass of the project overview widgets.",
    priority: "medium",
    dueDate: daysFromToday(2),
    tags: ["Feature", "Work"],
    status: "progress",
  },
  {
    id: "task-icons",
    title: "Export updated icon set",
    description: "",
    priority: "low",
    dueDate: "",
    tags: ["Design"],
    status: "done",
  },
];

const board = document.querySelector("#board-columns");
const activityList = document.querySelector("#activity-list");
const searchInput = document.querySelector("#search-input");
const priorityFilter = document.querySelector("#priority-filter");
const tagFilter = document.querySelector("#tag-filter");
const taskDialog = document.querySelector("#task-dialog");
const taskForm = document.querySelector("#task-form");
const formError = document.querySelector("#form-error");
const toastRegion = document.querySelector("#toast-region");
let draggedTaskId = null;
let toastTimeout;

let tasks = loadTasks();
let activities = loadActivities();

// Return a date in the YYYY-MM-DD format expected by date inputs.
function daysFromToday(offset) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return toDateInputValue(date);
}

function toDateInputValue(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function loadTasks() {
  const saved = localStorage.getItem(STORAGE_KEYS.tasks);
  if (saved === null) {
    localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(initialTasks));
    return initialTasks.map((task) => ({ ...task, tags: [...task.tags] }));
  }

  try {
    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed)) {
      throw new Error("Saved tasks must be a list.");
    }

    return parsed.filter(isValidTask).map((task) => ({
      ...task,
      tags: task.tags.map((tag) => String(tag).trim()).filter(Boolean),
    }));
  } catch (error) {
    console.error("Unable to read saved tasks; starting with an empty board.", error);
    return [];
  }
}

function isValidTask(task) {
  const hasValidText = task &&
    typeof task.id === "string" &&
    typeof task.title === "string" &&
    typeof task.description === "string";
  const hasValidPriority = ["low", "medium", "high"].includes(task?.priority);
  const hasValidStatus = COLUMNS.some((column) => column.id === task?.status);
  const hasValidTags = Array.isArray(task?.tags);

  return hasValidText && hasValidPriority && hasValidStatus && hasValidTags;
}

function loadActivities() {
  const saved = localStorage.getItem(STORAGE_KEYS.activity);
  if (saved === null) return [];
  try {
    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed)) {
      throw new Error("Saved activity must be a list.");
    }

    return parsed
      .filter((item) => item && typeof item.text === "string" && Number.isFinite(item.timestamp))
      .slice(0, 20);
  } catch (error) {
    console.error("Unable to read saved activity.", error);
    return [];
  }
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(tasks));
  } catch (error) {
    console.error("Unable to save tasks to local storage.", error);
    showToast("Could not save changes to this browser.");
  }
}

function saveActivities() {
  try {
    localStorage.setItem(STORAGE_KEYS.activity, JSON.stringify(activities));
  } catch (error) {
    console.error("Unable to save activity to local storage.", error);
    showToast("Could not save activity to this browser.");
  }
}

function escapeHtml(value) {
  const htmlEntities = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  };

  return String(value).replace(/[&<>"']/g, (character) => htmlEntities[character]);
}

// Update each visible area from the current task and activity data.
function render() {
  updateTagOptions();
  renderBoard();
  renderProgress();
  renderActivities();
}

function getFilteredTasks() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const priority = priorityFilter.value;
  const tag = tagFilter.value.toLocaleLowerCase();

  return tasks.filter((task) => {
    const matchesQuery = !query ||
      task.title.toLocaleLowerCase().includes(query) ||
      task.tags.some((item) => item.toLocaleLowerCase().includes(query));
    const matchesPriority = priority === "all" || task.priority === priority;
    const matchesTag = tag === "all" || task.tags.some((item) => item.toLocaleLowerCase() === tag);
    return matchesQuery && matchesPriority && matchesTag;
  });
}

function updateTagOptions() {
  const current = tagFilter.value;
  const tags = [...new Set(tasks.flatMap((task) => task.tags))].sort((a, b) => a.localeCompare(b));
  const tagOptions = tags
    .map((tag) => {
      const value = escapeHtml(tag.toLocaleLowerCase());
      const label = escapeHtml(tag);
      return `<option value="${value}">${label}</option>`;
    })
    .join("");

  tagFilter.innerHTML = `<option value="all">All tags</option>${tagOptions}`;
  const selectedTagStillExists = tags.some((tag) => tag.toLocaleLowerCase() === current);
  tagFilter.value = selectedTagStillExists ? current : "all";
}

function renderBoard() {
  const filteredTasks = getFilteredTasks();

  board.innerHTML = COLUMNS.map((column) => {
    const columnTasks = filteredTasks
      .filter((task) => task.status === column.id)
      .sort((firstTask, secondTask) => {
        const priorityDifference = priorityRank(secondTask.priority) - priorityRank(firstTask.priority);
        return priorityDifference || firstTask.title.localeCompare(secondTask.title);
      });
    const cards = columnTasks.map(renderTaskCard).join("");
    const hasNoSearchMatches = filteredTasks.length === 0 && tasks.length > 0;
    const emptyContent = hasNoSearchMatches
      ? {
        title: "No matching tasks",
        message: "Try changing your search or filters.",
      }
      : {
        title: "A little room to think",
        message: "Tasks added here will show up in this space.",
      };
    return `
      <section class="board-column ${column.className}" data-column="${column.id}" aria-label="${column.title} tasks">
        <header class="column-heading">
          <div class="column-title-group"><span class="column-dot"></span><h3>${column.title}</h3><span class="column-count">${columnTasks.length}</span></div>
          <button class="column-add" type="button" data-add-task="${column.id}" aria-label="Add task to ${column.title}"><span>+</span> Add task</button>
        </header>
        <div class="task-list" data-task-list="${column.id}">
          ${cards || renderEmptyState(emptyContent.title, emptyContent.message)}
        </div>
      </section>`;
  }).join("");
}

function priorityRank(priority) {
  const priorityScores = { high: 3, medium: 2, low: 1 };
  return priorityScores[priority] || 0;
}

function renderTaskCard(task) {
  const priority = task.priority[0].toUpperCase() + task.priority.slice(1);
  const tagElements = task.tags.map((tag) => {
    const normalized = tag.toLocaleLowerCase();
    const knownTagNames = ["bug", "design", "research", "feature"];
    const tagClass = knownTagNames.includes(normalized) ? ` tag-${normalized}` : "";
    return `<span class="task-tag${tagClass}">${escapeHtml(tag)}</span>`;
  }).join("");
  const tags = tagElements ? `<div class="card-tags">${tagElements}</div>` : "";
  const due = formatDueDate(task.dueDate, task.status);
  const description = task.description ? `<p class="task-description">${escapeHtml(task.description)}</p>` : "";
  return `
    <article class="task-card" draggable="true" data-task-id="${escapeHtml(task.id)}" aria-label="${escapeHtml(task.title)}, ${priority} priority">
      <div class="card-topline">
        <span class="priority-badge priority-${task.priority}">${priority}</span>
        <div class="card-actions">
          <button class="card-action edit-task" type="button" data-action="edit" data-task-id="${escapeHtml(task.id)}" aria-label="Edit ${escapeHtml(task.title)}" title="Edit task">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 5 4 4M4 20l4.3-.9L19 8.4a2.1 2.1 0 0 0-3-3L5.3 16.1 4 20Z"></path></svg>
          </button>
          <button class="card-action delete-task" type="button" data-action="delete" data-task-id="${escapeHtml(task.id)}" aria-label="Delete ${escapeHtml(task.title)}" title="Delete task">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M10 11v6m4-6v6M5 7l1 14h12l1-14M9 7V4h6v3"></path></svg>
          </button>
        </div>
      </div>
      <h4>${escapeHtml(task.title)}</h4>
      ${description}
      ${tags}
      <div class="card-footer"><span class="due-date ${due.className}">${calendarIcon()}<span>${due.text}</span></span><span class="card-assignee" aria-label="Assigned to Alex Morgan">AM</span></div>
    </article>`;
}

function calendarIcon() {
  return '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"></rect><path d="M16 3v4M8 3v4M3 10h18"></path></svg>';
}

function formatDueDate(value, status) {
  if (!value) {
    return { text: "No due date", className: "" };
  }

  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) {
    return { text: "No due date", className: "" };
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dayDiff = Math.round((date.getTime() - today.getTime()) / 86400000);
  const dateLabel = date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  if (status === "done") {
    return { text: dateLabel, className: "is-complete" };
  }
  if (dayDiff < 0) {
    return { text: `Overdue · ${dateLabel}`, className: "is-overdue" };
  }
  if (dayDiff === 0) {
    return { text: "Due Today", className: "is-today" };
  }

  return { text: dateLabel, className: "" };
}

function renderEmptyState(title, message) {
  return `<div class="empty-column">
    <div class="empty-illustration" aria-hidden="true">
      <svg viewBox="0 0 54 50"><path d="M10 13.5 27 5l17 8.5v21L27 43l-17-8.5v-21Z"></path><path d="m10 13.5 17 9 17-9M27 22.5V43"></path><path d="M18 9.5 35 18"></path></svg><span class="empty-spark">✦</span>
    </div><strong>${title}</strong><p>${message}</p>
  </div>`;
}

function renderProgress() {
  // reduce() counts completed tasks in one pass through the board.
  const completed = tasks.reduce((count, task) => {
    return task.status === "done" ? count + 1 : count;
  }, 0);
  const total = tasks.length;
  const percent = total ? Math.round((completed / total) * 100) : 0;
  const taskWord = total === 1 ? "task" : "tasks";

  document.querySelector("#progress-label").textContent = `${completed} of ${total} ${taskWord} completed`;
  document.querySelector("#progress-percent").textContent = `${percent}%`;
  const progress = document.querySelector(".progress-track");
  progress.setAttribute("aria-valuenow", String(percent));
  progress.querySelector(".progress-fill").style.width = `${percent}%`;
}

function renderActivities() {
  if (!activities.length) {
    activityList.innerHTML = '<p class="activity-empty">Your board updates will appear here.</p>';
    return;
  }
  activityList.innerHTML = activities.slice(0, 5).map((activity) => `
    <div class="activity-item">
      <span class="activity-avatar" aria-hidden="true">AM</span>
      <p class="activity-copy">${activity.text}<span class="activity-time">${timeAgo(activity.timestamp)}</span></p>
    </div>`).join("");
}

function timeAgo(timestamp) {
  const minutes = Math.max(0, Math.floor((Date.now() - timestamp) / 60000));
  if (minutes < 1) {
    return "just now";
  }
  if (minutes < 60) {
    const minuteWord = minutes === 1 ? "min" : "mins";
    return `${minutes} ${minuteWord} ago`;
  }

  const hours = Math.floor(minutes / 60);
  if (hours < 24) {
    const hourWord = hours === 1 ? "hr" : "hrs";
    return `${hours} ${hourWord} ago`;
  }

  const days = Math.floor(hours / 24);
  const dayWord = days === 1 ? "day" : "days";
  return `${days} ${dayWord} ago`;
}

function logActivity(text) {
  activities.unshift({ text, timestamp: Date.now() });
  activities = activities.slice(0, 20);
  saveActivities();
}

// The same form is pre-filled for edits and reset for newly created tasks.
function openTaskDialog(task, status = "todo") {
  taskForm.reset();
  formError.textContent = "";
  const isEditing = Boolean(task);

  document.querySelector("#task-id").value = isEditing ? task.id : "";
  document.querySelector("#dialog-title").textContent = isEditing ? "Edit task" : "Create a task";
  document.querySelector(".save-button-label").textContent = isEditing ? "Save changes" : "Create task";
  document.querySelector("#task-title").value = isEditing ? task.title : "";
  document.querySelector("#task-description").value = isEditing ? task.description : "";
  document.querySelector("#task-priority").value = isEditing ? task.priority : "medium";
  document.querySelector("#task-status").value = isEditing ? task.status : status;
  document.querySelector("#task-due-date").value = isEditing ? task.dueDate : "";
  document.querySelector("#task-tags").value = isEditing ? task.tags.join(", ") : "";

  taskDialog.showModal();
  requestAnimationFrame(() => document.querySelector("#task-title").focus());
}

function closeTaskDialog() {
  taskDialog.close();
  formError.textContent = "";
}

function showToast(message) {
  toastRegion.innerHTML = `<div class="toast">${escapeHtml(message)}</div>`;
  window.clearTimeout(toastTimeout);
  toastTimeout = window.setTimeout(() => {
    toastRegion.innerHTML = "";
  }, 2600);
}

// One listener handles buttons inside every card, including cards rendered later.
board.addEventListener("click", (event) => {
  const addButton = event.target.closest("[data-add-task]");
  if (addButton) {
    openTaskDialog(null, addButton.dataset.addTask || "todo");
    return;
  }

  const actionButton = event.target.closest("[data-action]");
  if (!actionButton) {
    return;
  }

  const selectedTask = tasks.find((task) => task.id === actionButton.dataset.taskId);
  if (!selectedTask) {
    return;
  }

  if (actionButton.dataset.action === "edit") {
    openTaskDialog(selectedTask);
  }

  if (actionButton.dataset.action === "delete") {
    deleteTask(selectedTask);
  }
});

function deleteTask(task) {
  const confirmed = window.confirm(`Delete "${task.title}"? This can't be undone.`);
  if (!confirmed) {
    return;
  }

  tasks = tasks.filter((savedTask) => savedTask.id !== task.id);
  saveTasks();
  logActivity(`Deleted <strong>${escapeHtml(task.title)}</strong>`);
  render();
  showToast("Task deleted.");
}

taskForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const taskData = readTaskForm();
  if (!taskData) {
    return;
  }

  const taskId = document.querySelector("#task-id").value;
  const existingTask = tasks.find((task) => task.id === taskId);
  const taskToSave = createTaskFromForm(taskData, existingTask);

  if (existingTask) {
    updateTask(taskToSave);
  } else {
    addTask(taskToSave);
  }

  saveTasks();
  closeTaskDialog();
  render();
});

function readTaskForm() {
  const formData = new FormData(taskForm);
  const title = String(formData.get("title") || "").trim();

  if (!title) {
    formError.textContent = "Please enter a task title.";
    document.querySelector("#task-title").focus();
    return null;
  }

  const tags = String(formData.get("tags") || "")
    .split(",")
    .map((tag) => tag.trim())
    .filter(Boolean);

  return {
    title,
    description: String(formData.get("description") || "").trim(),
    priority: String(formData.get("priority")),
    dueDate: String(formData.get("dueDate") || ""),
    tags: [...new Set(tags)],
    status: String(formData.get("status")),
  };
}

function createTaskFromForm(formData, existingTask) {
  return {
    id: existingTask ? existingTask.id : `task-${crypto.randomUUID()}`,
    ...formData,
  };
}

function updateTask(updatedTask) {
  tasks = tasks.map((task) => task.id === updatedTask.id ? updatedTask : task);
  logActivity(`Updated <strong>${escapeHtml(updatedTask.title)}</strong>`);
  showToast("Changes saved.");
}

function addTask(newTask) {
  tasks = [newTask, ...tasks];
  logActivity(`Created <strong>${escapeHtml(newTask.title)}</strong> in ${columnTitle(newTask.status)}`);
  showToast("Task created.");
}

function columnTitle(status) {
  const matchingColumn = COLUMNS.find((column) => column.id === status);
  return matchingColumn ? matchingColumn.title : "To Do";
}

document.querySelector(".dialog-close").addEventListener("click", closeTaskDialog);
document.querySelector(".dialog-cancel").addEventListener("click", closeTaskDialog);
taskDialog.addEventListener("click", (event) => {
  if (event.target === taskDialog) {
    closeTaskDialog();
  }
});
taskDialog.addEventListener("close", () => {
  formError.textContent = "";
});

searchInput.addEventListener("input", renderBoard);
priorityFilter.addEventListener("change", renderBoard);
tagFilter.addEventListener("change", renderBoard);

// Drag events are delegated from the board so newly rendered cards still work.
board.addEventListener("dragstart", (event) => {
  const card = event.target.closest(".task-card");
  if (!card) {
    return;
  }

  draggedTaskId = card.dataset.taskId;
  card.classList.add("is-dragging");
  event.dataTransfer.effectAllowed = "move";
  event.dataTransfer.setData("text/plain", draggedTaskId);
});

board.addEventListener("dragend", (event) => {
  const card = event.target.closest(".task-card");
  if (card) {
    card.classList.remove("is-dragging", "is-drop-invalid");
  }

  board.querySelectorAll(".is-drop-target").forEach((column) => {
    column.classList.remove("is-drop-target");
  });
  draggedTaskId = null;
});

board.addEventListener("dragover", (event) => {
  const column = event.target.closest(".board-column");
  if (!column || !draggedTaskId) {
    return;
  }

  event.preventDefault();
  event.dataTransfer.dropEffect = "move";
  column.classList.add("is-drop-target");
});

board.addEventListener("dragleave", (event) => {
  const column = event.target.closest(".board-column");
  const pointerLeftColumn = column && !column.contains(event.relatedTarget);

  if (pointerLeftColumn) {
    column.classList.remove("is-drop-target");
  }
});

board.addEventListener("drop", (event) => {
  const column = event.target.closest(".board-column");
  if (!column || !draggedTaskId) {
    return;
  }

  event.preventDefault();
  const targetStatus = column.dataset.column;
  const taskToMove = tasks.find((task) => task.id === draggedTaskId);

  if (!taskToMove) {
    return;
  }

  if (!taskToMove.title.trim()) {
    const droppedCard = event.target.closest(".task-card");
    if (droppedCard) {
      droppedCard.classList.add("is-drop-invalid");
    }
    showToast("A task needs a title before it can be moved.");
    return;
  }

  if (taskToMove.status === targetStatus) {
    return;
  }

  const previousStatus = taskToMove.status;
  tasks = tasks.map((task) => {
    return task.id === taskToMove.id
      ? { ...task, status: targetStatus }
      : task;
  });

  saveTasks();
  logActivity(
    `Moved <strong>${escapeHtml(taskToMove.title)}</strong> from ${columnTitle(previousStatus)} to ${columnTitle(targetStatus)}`
  );
  render();
});

const themeToggle = document.querySelector(".theme-toggle");

function applyTheme(theme) {
  document.body.dataset.theme = theme;
  localStorage.setItem(STORAGE_KEYS.theme, theme);
  themeToggle.setAttribute("aria-label", `Switch to ${theme === "dark" ? "light" : "dark"} mode`);
}

themeToggle.addEventListener("click", () => {
  const nextTheme = document.body.dataset.theme === "dark" ? "light" : "dark";
  applyTheme(nextTheme);
});

document.addEventListener("keydown", (event) => {
  const isTypingInFormField = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement.tagName);
  const canUseSearchShortcut = event.key === "/" && !isTypingInFormField && !taskDialog.open;

  if (canUseSearchShortcut) {
    event.preventDefault();
    searchInput.focus();
  }
});

const storedTheme = localStorage.getItem(STORAGE_KEYS.theme);
const initialTheme = storedTheme === "dark" ? "dark" : "light";
applyTheme(initialTheme);
render();
