# Flowboard

Flowboard is a responsive, Trello-style Kanban task manager built with plain HTML, CSS, and JavaScript. It includes a three-column task board, task editing, drag and drop, search, filters, progress tracking, and browser persistence.

## Features

- Three task columns: To Do, In Progress, and Done
- Create and edit tasks using the same validated modal form
- Delete tasks with a confirmation prompt
- Drag and drop tasks between columns using the HTML5 Drag and Drop API
- Real-time search across task titles and tags
- Priority and tag filters
- Task counts and completed-task progress, recalculated as tasks change
- Due date labels for overdue tasks and tasks due today
- Activity feed for task creation, editing, deletion, and status changes
- Task data, activity, and theme preference saved in `localStorage`
- Light and dark themes
- Responsive board layouts, keyboard-friendly controls, and empty states

## Tech used

- HTML5, including the native `<dialog>` element
- CSS3 with Grid, Flexbox, responsive media queries, and reduced-motion support
- Vanilla JavaScript ES6+
- Browser APIs: DOM events, HTML5 Drag and Drop, `Date`, `localStorage`, and `confirm`

## Code tour

- `index.html` contains the page sections, board container, filters, and task form.
- `style.css` defines the colors, cards, columns, dialog, and responsive layouts.
- `app.js` owns the task data and the interactions. It is organized into small jobs:
  - `loadTasks()` and `saveTasks()` read and write the board in local storage.
  - `getFilteredTasks()` applies the search and selected filters.
  - `renderBoard()` turns task data into cards and columns.
  - `readTaskForm()`, `addTask()`, and `updateTask()` handle form submissions.
  - The `dragstart`, `dragover`, and `drop` listeners move cards between columns.

Each task is a plain JavaScript object with an `id`, `title`, `description`, `priority`, `dueDate`, `tags`, and `status`. Changing a task updates this data first; the app then saves it and redraws the affected board views.

## How drag and drop works

Task cards use the native `draggable` attribute. A delegated `dragstart` listener stores the task ID in the drag state and the data transfer object. Board columns handle `dragover` and `drop`; dropping updates the matching task's status in the in-memory array, saves the new state to local storage, records an activity entry, and re-renders the board and counts. A task must have a non-empty title to be moved.

## Run locally

1. Download or clone this folder.
2. Open `index.html` in a modern browser. No build step, server, package installation, or framework is required.
3. Add or move tasks; the board is saved automatically in that browser.

The first visit loads a small sample board so the interactions are immediately visible. Task, activity, and theme data are stored locally in the browser and are not sent to a server.

## Screenshots

Capture these views in a browser at the indicated layouts:

- **Board view:** open `index.html` at a desktop width.
- **Add Task modal:** choose **Add task**.
- **Drag in action:** drag any card over a different status column.
- **Mobile view:** narrow the browser viewport to a phone width; the columns scroll horizontally.
- **Light/Dark mode:** use the theme button in the top-right corner.
